# Install / publicar no perfil

Seu GitHub usa o username **Koratsu**. Para o README aparecer diretamente no perfil, o GitHub exige um repositório **público** chamado exatamente `Koratsu`, com `README.md` na raiz.

## Opção mais rápida — pela interface do GitHub

1. No GitHub, clique em **New repository**.
2. Repository name: `Koratsu`.
3. Visibility: **Public**.
4. Crie o repositório.
5. Use **Add file → Upload files**.
6. Envie `README.md`, `README.pt-BR.md` e a pasta `assets/` mantendo a estrutura.
7. Faça o commit na branch `main`.
8. Abra `https://github.com/Koratsu`: o `README.md` aparecerá automaticamente no perfil.

## Idiomas

O GitHub não permite JavaScript em README e não possui abas interativas de idioma. A solução mais limpa é esta usada no pacote:

- `README.md` = inglês, que aparece por padrão no perfil.
- `README.pt-BR.md` = versão integral em português.
- O seletor `English · Português` no topo troca entre os dois arquivos.

## Banner animado

O arquivo `assets/pedro-systems.gif` tem **1200 × 300 px**, proporção **4:1**, praticamente a mesma proporção visual do banner da referência enviada. Ele já está referenciado com `width="100%"`, então se adapta à largura do README.

O GitHub aceita GIFs em profile READMEs. Para substituir no futuro, mantenha preferencialmente:

- proporção: **4:1**
- resolução recomendada: **1200×300** ou **1600×400**
- loop curto e discreto
- pouco texto dentro do GIF
- arquivo enxuto para carregar rápido

## Bio recomendada

`Founder @ BRIX · Building software and systems that connect digital decisions to real-world operations.`

## Estrutura final

```text
Koratsu/
├── README.md
├── README.pt-BR.md
└── assets/
    ├── pedro-systems.gif
    └── pedro-systems-preview.png
```
