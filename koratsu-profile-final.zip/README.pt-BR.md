<p align="right">
  <a href="./README.md">🇺🇸 English</a> · <b>🇧🇷 Português</b>
</p>

<p align="center">
  <img src="./assets/pedro-systems.gif" alt="Pedro Lopes — console de sistemas" width="100%" />
</p>

<h1 align="center">Pedro Lopes</h1>
<p align="center">
  <b>Founder · Construtor de Produtos · Pensamento Sistêmico</b><br/>
  Construindo software e sistemas que conectam decisões digitais a operações do mundo real.
</p>

---

### `01 / construindo agora`

**BRIX** — uma camada operacional para o setor alimentício, começando pela panificação.

Estou construindo a BRIX como um sistema conectado de **produtos, ferramentas digitais, conhecimento técnico, dados e educação**. A ideia não é lançar funcionalidades isoladas; é tornar operações melhores mais repetíveis, mensuráveis e fáceis de escalar.

```text
problema real → modelo → software → operação → dados → alavancagem
```

### `02 / o que eu construo`

| Camada | O que isso significa na prática |
| --- | --- |
| **Produto** | Ferramentas úteis, UX clara e sistemas em que as pessoas possam confiar. |
| **Software** | Sistemas web, automações, ferramentas internas e produtos de dados. |
| **Operações** | Fluxos repetíveis, menos repasses manuais e melhor visibilidade. |
| **Negócio** | Distribuição, economia unitária e vantagens que se acumulam com o tempo. |

### `03 / stack e interesses atuais`

`WordPress` · `PHP` · `JavaScript` · `HTML/CSS` · `Git/GitHub` · `Automação` · `Dados` · `Sistemas de Produto`

<details>
<summary><b>Como eu penso sobre construir</b></summary>
<br/>

Eu me interesso pelo ponto em que código deixa de ser uma demonstração e passa a se comportar como infraestrutura.

Os melhores sistemas não são necessariamente os que possuem mais funcionalidades. Eles reduzem incerteza, facilitam decisões, tornam o que importa visível e continuam funcionando quando a operação cresce.

Costumo pensar em ciclos:

```text
observar → modelar → construir → instrumentar → aprender → melhorar
```

</details>

---

<p align="center">
  <code>útil antes de impressionante · confiável antes de complexo · escalável depois de provado</code>
</p>
